package Calc;

import blockchain.Utils;
import blockchain.btcd.Zec;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Test {
    static {
        System.setProperty("fileName", "zec/zec.log");
    }
    public static Logger log = LoggerFactory.getLogger(Zec.class);
    public static void main(String[] args) throws IOException {
//        String url = "http://192.168.200.51:10320/risk/tbex-risk-engine-config/orderRecord/searchAllRecord";
//        String params = "{\"pageIndex\":1,\"pageSize\":100,\"filters\":{\"userId\":\"333385034\",\"currencys\":\"1001,1002\",\"businessId\":2,\"strTime\":\"\",\"endTime\":\"\"}}";
//        String au = "Bearer 396fe35d-7716-2413-48ca-a4a2-5b0d0078e02f";
////        System.out.println(BaseUtils.postByJson(url,au,params));
//        List<BigDecimal> list = new ArrayList<BigDecimal>();
//        list.add(0,new BigDecimal(0));
//        list.add(0,list.get(0).add(new BigDecimal(111)));
//        list.add(0,list.get(0).add(new BigDecimal(111)));
//        System.out.println(list.get(0));
//        System.out.println(list);

//        String fileName = "userId.txt";
//        for (int i= 10000 ; i <=30000 ; i++){
//            Utils.writerData1(fileName,""+i);
//        }

//        System.out.println(0.2*Math.pow(10.0,2));
//        System.out.println(DictEnum.BTC.getCurrency());
//        System.out.println(DictEnum.values().length);
//
//        for (DictEnum e : DictEnum.values()) {
//            System.out.println(e.getCurrency());
//        }

String address = "TNQR9CgoMNqFjcsQZBYZZB7thj91jZQDcW";
        System.out.println(stringToAscii(address));

    }
    public static String stringToAscii(String value)
    {
        StringBuffer sbu = new StringBuffer();
        char[] chars = value.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if(i != chars.length - 1)
            {
                sbu.append((int)chars[i]).append(",");
            }
            else {
                sbu.append((int)chars[i]);
            }
        }
        return sbu.toString();
    }
}
